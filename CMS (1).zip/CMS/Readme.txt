 For admin Panel http://localhost/loginsystem/admin

Credentials for admin panel :

Username: admin
Password: Test@12345

Credentials for user panel : 

Username: brian@gmail.com
Password : Test@123
