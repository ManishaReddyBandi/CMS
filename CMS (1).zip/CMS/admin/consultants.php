<?php session_start();
include_once('../includes/config.php');
if (strlen($_SESSION['adminid']==0)) {
  header('location:logout.php');
  } else{
    
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>CMS consultants</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
   <?php include_once('includes/navbar.php');?>
        <div id="layoutSidenav">
          <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4 text-center fw-bolder display-2">Consultants</h1>
                        
                        <br>
                   <!-- another row -->
                   <div class="row">
                   <section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center bg-warning">
				<div class="col-md-6 text-center sm-5">
					<h4 class="heading-section">Consultants Details</h4>
				</div>
			</div>
			<div class="row">


				<div class="col-md-12">
					<div class="table-wrap">
						<table class="table table-striped table-responsive">
						  <thead>
						    <tr>
						      <th>Consultant_ID </th>
						      <th>Consultant_Name</th>
						      <th>Consultant_Contact</th>
						      <th>Consultant_Email</th>
						      <th>Consultant_Address </th>
                 				      <th>Consultant_City</th>
						      <th>Consultant_State </th>
						      <th>status</th>
						    </tr>
						  </thead>
						  <tbody>
                 
              
              <?php
              // SQL query to select data from database
              $sql = "SELECT * FROM consultant";
              $result = $con->query($sql);
                // LOOP TILL END OF DATA
                while($rows=$result->fetch_assoc())
                {
            ?>
						    <tr>
						      <th scope="row"><?php echo $rows['Consultant_ID'];?></th>
						      <td> <?php echo $rows['Consultant_Name'];?></td>
						      <td> <?php echo $rows['Consultant_Contact'];?></td>
						      <td> <?php echo $rows['Consultant_Email'];?></td>
						      <td><?php echo $rows['Consultant_Address'];?></td>
                 					 <td> <?php echo $rows['Consultant_City'];?></td>
						      <td><?php echo $rows['Consultant_State'];?></td>
						      <td><a href="#" class="btn btn-success">Active</a></td>
						    </tr>
                <?php
                }
            ?>
						    
						  </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>

                            
                        </div>
                   <!-- end of another row -->
                      
                    </div>
                </main>
             
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="../js/datatables-simple-demo.js"></script>
    </body>
</html>
<?php } ?>
