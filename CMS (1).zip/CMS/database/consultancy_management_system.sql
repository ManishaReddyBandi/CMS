-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2022 at 08:28 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `consultancy_mgt_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '5c428d8875d2948607f3e3fe134d71b4');

-- --------------------------------------------------------

--
-- Table structure for table `certification`
--

CREATE TABLE `certification` (
  `Certification_ID` int(11) NOT NULL,
  `Certification_Name` varchar(45) DEFAULT NULL,
  `Certification_Date` date DEFAULT NULL,
  `Level_Of_Certification` varchar(45) DEFAULT NULL,
  `Skill_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `certification`
--

INSERT INTO `certification` (`Certification_ID`, `Certification_Name`, `Certification_Date`, `Level_Of_Certification`, `Skill_ID`) VALUES
(10, 'python', '2022-01-28', 'Beginner', 2),
(11, 'database', '2022-02-10', 'Mediator', 4),
(12, 'html', '2021-05-20', 'Proficient', 8),
(13, 'cloudComputing', '2021-03-20', 'Beginner', 10),
(14, 'sap', '2021-04-20', 'Mediator', 5),
(15, 'database', '2022-04-01', 'Beginner', 4),
(16, 'html', '2021-06-20', 'Proficient', 8),
(17, 'php', '2022-01-01', 'Mediator', 7),
(18, 'c', '2022-05-04', 'Proficient', 3),
(19, 'python', '2022-04-05', 'Mediator', 2);

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `Client_ID` int(11) NOT NULL,
  `Client_Name` varchar(45) DEFAULT NULL,
  `Client_Contact_Name` varchar(45) DEFAULT NULL,
  `Client_Contact_Mobile` varchar(45) DEFAULT NULL,
  `Client_Contact_Email` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`Client_ID`, `Client_Name`, `Client_Contact_Name`, `Client_Contact_Mobile`, `Client_Contact_Email`) VALUES
(111, 'value org', 'abraham', '9999999999', 'abraham@value.org'),
(222, 'trump corp', 'trump', '9999988888', 'trumpd@trump.corp'),
(333, 'mta org', 'micheal', '9999977777', 'micheal@mta.org'),
(444, 'tcs', 'ratan', '9998887777', 'ratan@tcs.org'),
(555, 'microsoft', 'michelle', '9898989898', 'michelle@microsoft.services'),
(666, 'amazon', 'vishwa', '9000000001', 'vishwa@amazon.com'),
(777, 'sonata', 'bunty', '9199999999', 'bunty@sonata.org.in'),
(888, 'infosys', 'sunny', '7897897899', 'sunny@infosys.co.in'),
(990, 'amdocs', 'raj', '8978978978', 'raj@amdocs.co.com'),
(999, 'landt', 'yankee', '9879879877', 'yankee@landt.corp');

-- --------------------------------------------------------

--
-- Table structure for table `consultant`
--

CREATE TABLE `consultant` (
  `Consultant_ID` int(11) NOT NULL,
  `Consultant_Name` varchar(45) DEFAULT NULL,
  `Consultant_Contact` varchar(45) DEFAULT NULL,
  `Consultant_Email` varchar(45) DEFAULT NULL,
  `Consultant_Address` varchar(45) DEFAULT NULL,
  `Consultant_City` varchar(45) DEFAULT NULL,
  `Consultant_State` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `consultant`
--

INSERT INTO `consultant` (`Consultant_ID`, `Consultant_Name`, `Consultant_Contact`, `Consultant_Email`, `Consultant_Address`, `Consultant_City`, `Consultant_State`) VALUES
(201, 'jspider', '12345', 'jspider@gmail.com', '320 parkave', 'bridgeport', 'connecticut'),
(202, 'talents', '12333', 'talants@gmail.com', '390 parkave', 'bridgeport', 'connecticut'),
(203, 'codev', '12222', 'codev@gmail.com', '99 fairfield', 'bridgeport', 'connecticut'),
(204, 'wecode', '11111', 'wecode@yahoo.com', '101 seastreet', 'orlando', 'florida'),
(205, 'codex', '22222', 'codex@gmail.com', '220 myrtle ', 'dallas', 'texas'),
(206, 'umass', '33333', 'umass@yahoo.com', '111 saintave', 'amherst', 'massachusetts'),
(207, 'umass', '44444', 'umassboston@gmail.com', '444 bostonroad', 'boston', 'massachusetts'),
(208, 'talents', '5555', 'talents2@gmail.com', '77 chapelst', 'new haven', 'connecticut'),
(209, 'ulearn', '66666', 'ulearn@gmail.com', '101 jacksonst', 'jacksonville', 'florida'),
(210, 'learn code', '77777', 'learncode@gmail.com', '111 losavenue', 'los angels', 'california');

-- --------------------------------------------------------

--
-- Table structure for table `consultant_skill`
--

CREATE TABLE `consultant_skill` (
  `Consultant_ID` int(11) NOT NULL,
  `Skill_Duration` varchar(45) DEFAULT NULL,
  `Skill_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `Project_ID` int(11) NOT NULL,
  `Project_Name` varchar(45) DEFAULT NULL,
  `Project_Manager` varchar(45) DEFAULT NULL,
  `Project_Location` varchar(45) DEFAULT NULL,
  `Client_Client_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`Project_ID`, `Project_Name`, `Project_Manager`, `Project_Location`, `Client_Client_ID`) VALUES
(1331, 'CBRE', 'Joe', 'Texas', 222),
(1332, 'Microsoft', 'Jim', 'Texas', 999),
(1333, 'Glass Enterprise Edition', 'Mary', 'California', 777),
(1334, 'Waymo', 'Sara', 'California', 777),
(1335, 'Chronicle', 'Alia', 'Washington DC', 333),
(1336, 'Makani', 'Jack', 'Texas', 111),
(1337, 'Verily', 'Paul', 'North Carolina', 111),
(1338, 'Signa', 'Don', 'Texas', 999),
(1339, 'Scotia', 'Jhon', 'Texas', 999),
(1340, 'Jhonson', 'Tim', 'Texas', 888);

-- --------------------------------------------------------

--
-- Table structure for table `project_consultant`
--

CREATE TABLE `project_consultant` (
  `Project_Consultant_ID` int(11) NOT NULL,
  `Start_Date` date NOT NULL,
  `End_Date` date NOT NULL,
  `Evaluation_Date` date NOT NULL,
  `Person_Evaluted` varchar(45) NOT NULL,
  `Evaluation_Score` varchar(45) NOT NULL,
  `Comments` varchar(45) NOT NULL,
  `Consultant_ID` int(11) NOT NULL,
  `Project_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `project_skill`
--

CREATE TABLE `project_skill` (
  `Project_Skill_ID` int(11) NOT NULL,
  `Skill_Updation` varchar(45) DEFAULT NULL,
  `Project_ID` int(11) NOT NULL,
  `Skill_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `project_skill`
--

INSERT INTO `project_skill` (`Project_Skill_ID`, `Skill_Updation`, `Project_ID`, `Skill_ID`) VALUES
(7001, 'yes', 1332, 5),
(7002, 'No', 1335, 6),
(7003, 'Yes', 1336, 7),
(7004, 'No', 1333, 10);

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `Review_ID` int(11) NOT NULL,
  `Rating` varchar(45) DEFAULT NULL,
  `Feedback` varchar(45) DEFAULT NULL,
  `Appraisal` varchar(45) DEFAULT NULL,
  `Client_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`Review_ID`, `Rating`, `Feedback`, `Appraisal`, `Client_ID`) VALUES
(30, '3', 'good', 'yes', 111),
(31, '2', 'poor', 'no', 111),
(32, '5', 'excellent', 'yes', 666),
(33, '4', 'better', 'yes', 555),
(34, '4', 'better', 'yes', 222),
(35, '4', 'better', 'yes', 111),
(36, '5', 'excellent', 'yes', 888),
(37, '1', 'poor', 'no', 666),
(38, '3', 'good', 'yes', 990),
(39, '2', 'poor', 'no', 999);

-- --------------------------------------------------------

--
-- Table structure for table `skill`
--

CREATE TABLE `skill` (
  `Skill_ID` int(11) NOT NULL,
  `Skill_Name` varchar(45) DEFAULT NULL,
  `Skill_Description` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `skill`
--

INSERT INTO `skill` (`Skill_ID`, `Skill_Name`, `Skill_Description`) VALUES
(2, 'Python', 'It is an interpreted, highlevel programming language'),
(3, 'C', 'It is a general purpose programming language'),
(4, 'Database', 'It is an organized collection of structred information'),
(5, 'Sap', 'It is widely used for resource planning software'),
(6, 'Visual basic', 'It is an event-driven programming language'),
(7, 'Php', 'It is server side scripting language'),
(8, 'Html', 'It is a formatting system for displaying material'),
(9, 'C#', 'It is a type-safe programming language'),
(10, 'Cloud computing', 'It has the computing services like storage,networking etc');

-- --------------------------------------------------------

--
-- Table structure for table `subproject`
--

CREATE TABLE `subproject` (
  `SubProject_ID` int(11) NOT NULL,
  `SubProject_Name` varchar(45) DEFAULT NULL,
  `Project_Description` varchar(45) DEFAULT NULL,
  `SubProject_Lead` varchar(45) DEFAULT NULL,
  `Project_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subproject`
--

INSERT INTO `subproject` (`SubProject_ID`, `SubProject_Name`, `Project_Description`, `SubProject_Lead`, `Project_ID`) VALUES
(13311, 'digion', 'It deals with moblie technologies', 'dillon', 1331),
(13322, 'space digital', 'It deals with satellite technology', 'peter', 1332),
(13333, 'webio', 'It deals web technolgy', 'sunny', 1332),
(13344, 'techme', 'It deals with automotive software', 'brooke', 1335),
(13355, 'dev AI', 'It deals with AI tech sw', 'kenny', 1337),
(13366, 'programmable', 'It deals with technology used inplanes', 'katy', 1339),
(13377, 'systemic', 'It deals with system softwares', 'zee', 1339),
(13388, 'transio', 'It deals with technology of trains', 'steve', 1333),
(13399, 'minify', 'It deals with technology of wifi', 'chris', 1339),
(13400, 'grammio', 'It deals with softwares used in banking', 'tony', 1336);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(300) DEFAULT NULL,
  `contactno` varchar(11) DEFAULT NULL,
  `posting_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `email`, `password`, `contactno`, `posting_date`) VALUES
(13, 'brian', 'nyachae', 'brian@gmail.com', 'Test@123', '0710889090', '2021-08-09 18:30:00'),
(15, 'bree', 'bree', 'bree@gmail.com', 'Bree123', '0710889090', '2022-06-09 11:49:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `certification`
--
ALTER TABLE `certification`
  ADD PRIMARY KEY (`Certification_ID`),
  ADD KEY `fk_Certification_Skill1_idx` (`Skill_ID`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`Client_ID`);

--
-- Indexes for table `consultant`
--
ALTER TABLE `consultant`
  ADD PRIMARY KEY (`Consultant_ID`);

--
-- Indexes for table `consultant_skill`
--
ALTER TABLE `consultant_skill`
  ADD PRIMARY KEY (`Consultant_ID`),
  ADD KEY `fk_Consultant_Skill_Consultant1_idx` (`Consultant_ID`),
  ADD KEY `fk_Consultant_Skill_Skill1_idx` (`Skill_ID`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`Project_ID`,`Client_Client_ID`),
  ADD KEY `fk_Project_Client1_idx` (`Client_Client_ID`);

--
-- Indexes for table `project_consultant`
--
ALTER TABLE `project_consultant`
  ADD PRIMARY KEY (`Project_Consultant_ID`),
  ADD KEY `fk_Project_Consultant_Consultant_idx` (`Consultant_ID`),
  ADD KEY `fk_Project_Consultant_Project1_idx` (`Project_ID`);

--
-- Indexes for table `project_skill`
--
ALTER TABLE `project_skill`
  ADD PRIMARY KEY (`Project_Skill_ID`),
  ADD KEY `fk_Project_Skill_Skill1_idx` (`Skill_ID`),
  ADD KEY `fk_Project_Skill_Project1` (`Project_ID`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`Review_ID`),
  ADD KEY `fk_Review_Client1` (`Client_ID`);

--
-- Indexes for table `skill`
--
ALTER TABLE `skill`
  ADD PRIMARY KEY (`Skill_ID`);

--
-- Indexes for table `subproject`
--
ALTER TABLE `subproject`
  ADD PRIMARY KEY (`SubProject_ID`,`Project_ID`),
  ADD KEY `fk_SubProject_Project1_idx` (`Project_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `certification`
--
ALTER TABLE `certification`
  ADD CONSTRAINT `fk_Certification_Skill1` FOREIGN KEY (`Skill_ID`) REFERENCES `skill` (`Skill_ID`);

--
-- Constraints for table `consultant_skill`
--
ALTER TABLE `consultant_skill`
  ADD CONSTRAINT `fk_Consultant_Skill_Consultant1` FOREIGN KEY (`Consultant_ID`) REFERENCES `consultant` (`Consultant_ID`),
  ADD CONSTRAINT `fk_Consultant_Skill_Skill1` FOREIGN KEY (`Skill_ID`) REFERENCES `skill` (`Skill_ID`);

--
-- Constraints for table `project`
--
ALTER TABLE `project`
  ADD CONSTRAINT `fk_Project_Client1` FOREIGN KEY (`Client_Client_ID`) REFERENCES `client` (`Client_ID`);

--
-- Constraints for table `project_consultant`
--
ALTER TABLE `project_consultant`
  ADD CONSTRAINT `fk_Project_Consultant_Consultant` FOREIGN KEY (`Consultant_ID`) REFERENCES `consultant` (`Consultant_ID`),
  ADD CONSTRAINT `fk_Project_Consultant_Project1` FOREIGN KEY (`Project_ID`) REFERENCES `project` (`Project_ID`);

--
-- Constraints for table `project_skill`
--
ALTER TABLE `project_skill`
  ADD CONSTRAINT `fk_Project_Skill_Project1` FOREIGN KEY (`Project_ID`) REFERENCES `project` (`Project_ID`),
  ADD CONSTRAINT `fk_Project_Skill_Skill1` FOREIGN KEY (`Skill_ID`) REFERENCES `skill` (`Skill_ID`);

--
-- Constraints for table `review`
--
ALTER TABLE `review`
  ADD CONSTRAINT `fk_Review_Client1` FOREIGN KEY (`Client_ID`) REFERENCES `client` (`Client_ID`);

--
-- Constraints for table `subproject`
--
ALTER TABLE `subproject`
  ADD CONSTRAINT `fk_SubProject_Project1` FOREIGN KEY (`Project_ID`) REFERENCES `project` (`Project_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
