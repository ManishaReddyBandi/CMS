<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>CMS </title>
        <link href="css/styles.css" rel="stylesheet" />
        <link href="css/custom.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
    </head>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">CMS consultancy</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        
        
        </ul>
      <form class="d-flex">
             <a class="nav-link me-2" href="signup.php">NEW USER</a>
     		 <a class="nav-link me-2" href="login.php">LOGIN</a>
          	<a class="nav-link me-2 " href="admin">ADMIN</a>
      </form>
    </div>
  </div>
</nav>
    <header id="first">
        <div class="header-content">
            <div class="inner">
                <h2 class="ml13" >CONSULTANCY MANAGEMENT SYSTEM</h2>
                <h4 class="cursive ml13">The perfect system for management...</h4>
                <hr>
                <a href="signup.php" class="btn btn-primary btn-xl page-scroll">Get Started</a>

            </div>
        </div>
        
    </header>
    
    
  
    



    </html>